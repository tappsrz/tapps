#!/bin/bash

caddy run --config Caddyfile
 